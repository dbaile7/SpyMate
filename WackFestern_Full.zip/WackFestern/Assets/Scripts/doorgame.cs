﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using SocketIO;

public class doorgame : MonoBehaviour {

    //socket used for communication between server
    private SocketIOComponent socket;

    public GameObject door;

    // Use this for initialization
    void Start () {
        socket = ((GameObject.FindGameObjectWithTag("Socket")).GetComponent<socket>()).getSocket();
    }
	
	// Update is called once per frame
	void Update () {
        //Start game
        if (Input.GetKey(KeyCode.E))
        {
            if (Vector3.Distance(gameObject.transform.position, door.transform.position) < 5)
            {
                SceneManager.LoadScene("pinball");

                socket.Emit("StartTiltGame");
            }
        }
    }
}
